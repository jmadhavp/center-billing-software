
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, DateTime, Float, Integer
from sqlalchemy.orm import relationship

from backend.core.database import Base

class Stock(Base):
    __tablename__ = "stock"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, nullable=False, unique=True)
    quantity = Column(Float, default=0.0)
    value = Column(Float, default=0.0)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    product = relationship("Product", back_populates="stock")
    stock_movements = relationship("StockMovement", back_populates="stock")
