
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import relationship

from backend.core.database import Base

class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(Integer, primary_key=True, index=True)
    invoice_number = Column(String, unique=True, nullable=False)
    invoice_date = Column(DateTime, default=datetime.utcnow)
    due_date = Column(DateTime)
    invoice_type = Column(String, default="sale")  # sale, purchase, credit_note, debit_note
    status = Column(String, default="draft")  # draft, sent, paid, partial, cancelled
    subtotal = Column(Float, default=0.0)
    discount_amount = Column(Float, default=0.0)
    tax_amount = Column(Float, default=0.0)
    total_amount = Column(Float, default=0.0)
    notes = Column(Text)
    terms = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company_id = Column(Integer, nullable=False)
    company = relationship("Company", back_populates="invoices")
    customer_id = Column(Integer, nullable=True)
    customer = relationship("Customer", back_populates="invoices")
    supplier_id = Column(Integer, nullable=True)
    supplier = relationship("Supplier", back_populates="purchase_invoices")
    items = relationship("InvoiceItem", back_populates="invoice", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="invoice")
