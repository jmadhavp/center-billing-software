
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, DateTime, Float, Integer, String
from sqlalchemy.orm import relationship

from backend.core.database import Base

class LedgerEntry(Base):
    __tablename__ = "ledger_entries"

    id = Column(Integer, primary_key=True, index=True)
    entry_date = Column(DateTime, default=datetime.utcnow)
    description = Column(String)
    debit_amount = Column(Float, default=0.0)
    credit_amount = Column(Float, default=0.0)
    balance = Column(Float, default=0.0)
    reference_type = Column(String)  # invoice, payment, journal
    reference_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    ledger_id = Column(Integer, nullable=False)
    ledger = relationship("Ledger", back_populates="entries")
