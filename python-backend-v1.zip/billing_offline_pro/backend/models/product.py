
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String
from sqlalchemy.orm import relationship

from backend.core.database import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    hsn_code = Column(String, nullable=True)
    sku = Column(String, unique=True, nullable=True)
    description = Column(String)
    unit = Column(String, default="Nos")
    price = Column(Float, default=0.0)
    cost_price = Column(Float, default=0.0)
    tax_rate = Column(Float, default=0.0)  # GST rate in percentage
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company_id = Column(Integer, nullable=False)
    company = relationship("Company", back_populates="products")
    invoice_items = relationship("InvoiceItem", back_populates="product")
    stock = relationship("Stock", back_populates="product", uselist=False)
