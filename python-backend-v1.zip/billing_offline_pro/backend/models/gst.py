
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String
from sqlalchemy.orm import relationship

from backend.core.database import Base

class GST(Base):
    __tablename__ = "gst"

    id = Column(Integer, primary_key=True, index=True)
    gstn_year = Column(String, nullable=False)
    gstn_month = Column(String, nullable=False)
    gst_type = Column(String, default="sales")  # sales, purchase
    taxable_amount = Column(Float, default=0.0)
    cgst_amount = Column(Float, default=0.0)
    sgst_amount = Column(Float, default=0.0)
    igst_amount = Column(Float, default=0.0)
    total_amount = Column(Float, default=0.0)
    is_reversed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    company_id = Column(Integer, nullable=False)
    company = relationship("Company")
