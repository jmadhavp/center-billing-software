
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import relationship

from backend.core.database import Base

class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    payment_number = Column(String, unique=True, nullable=False)
    payment_date = Column(DateTime, default=datetime.utcnow)
    payment_type = Column(String, default="receipt")  # receipt, payment, receipt_voucher, payment_voucher
    amount = Column(Float, default=0.0)
    payment_method = Column(String, default="cash")  # cash, bank_transfer, cheque, upi, card
    reference_number = Column(String)
    notes = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    company_id = Column(Integer, nullable=False)
    company = relationship("Company", back_populates="payments")
    invoice_id = Column(Integer, nullable=True)
    invoice = relationship("Invoice", back_populates="payments")
    customer_id = Column(Integer, nullable=True)
    supplier_id = Column(Integer, nullable=True)
