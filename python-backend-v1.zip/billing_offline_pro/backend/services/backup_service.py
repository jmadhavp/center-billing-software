
import sqlite3
import os
import shutil
from datetime import datetime
from typing import Optional

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from backend.core.config import settings
from backend.core.database import get_db

class BackupService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def create_backup(self, backup_name: Optional[str] = None) -> str:
        if not backup_name:
            backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        backup_path = os.path.join(os.path.dirname(settings.DATABASE_URL.replace("sqlite:///", "")), "backups", backup_name)

        # Create backups directory if it doesn't exist
        os.makedirs(os.path.dirname(backup_path), exist_ok=True)

        # Copy the database file
        source_db = settings.DATABASE_URL.replace("sqlite:///", "")
        shutil.copy(source_db, backup_path + ".db")

        # Also create a SQL dump
        self._create_sql_dump(backup_path + ".sql")

        return backup_path

    def restore_backup(self, backup_path: str) -> bool:
        try:
            # Copy the backup file back to the original location
            source_db = settings.DATABASE_URL.replace("sqlite:///", "")
            shutil.copy(backup_path, source_db)
            return True
        except Exception as e:
            print(f"Error restoring backup: {e}")
            return False

    def list_backups(self) -> list:
        backup_dir = os.path.join(os.path.dirname(settings.DATABASE_URL.replace("sqlite:///", "")), "backups")
        if not os.path.exists(backup_dir):
            return []

        backups = []
        for file_name in os.listdir(backup_dir):
            if file_name.endswith(".db"):
                backups.append({
                    "name": file_name.replace(".db", ""),
                    "size": os.path.getsize(os.path.join(backup_dir, file_name)),
                    "created_at": datetime.fromtimestamp(os.path.getctime(os.path.join(backup_dir, file_name)))
                })

        return sorted(backups, key=lambda x: x["created_at"], reverse=True)

    def _create_sql_dump(self, dump_path: str):
        conn = sqlite3.connect(settings.DATABASE_URL.replace("sqlite:///", ""))
        with open(dump_path, 'w') as f:
            for line in conn.iterdump():
                f.write(f'{line}\n')
        conn.close()
