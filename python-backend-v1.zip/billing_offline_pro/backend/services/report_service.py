
from typing import List, Optional
from datetime import datetime

from sqlalchemy.orm import Session

from backend.models.invoice import Invoice
from backend.models.payment import Payment
from backend.models.gst import GST
from backend.schemas.reports import SalesReport, PurchaseReport, GSTReport, TrialBalanceReport, ProfitLossReport
from backend.core.database import get_db

class ReportService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def get_sales_report(self, report_data: SalesReport) -> dict:
        sales = self.db.query(Invoice).filter(
            Invoice.company_id == report_data.company_id,
            Invoice.invoice_type == "sale",
            Invoice.invoice_date >= report_data.start_date,
            Invoice.invoice_date <= report_data.end_date,
            Invoice.is_active == True
        ).all()

        total_sales = sum(invoice.total_amount for invoice in sales)
        total_tax = sum(invoice.tax_amount for invoice in sales)

        return {
            "total_sales": total_sales,
            "total_tax": total_tax,
            "invoice_count": len(sales),
            "sales_data": sales
        }

    def get_purchase_report(self, report_data: PurchaseReport) -> dict:
        purchases = self.db.query(Invoice).filter(
            Invoice.company_id == report_data.company_id,
            Invoice.invoice_type == "purchase",
            Invoice.invoice_date >= report_data.start_date,
            Invoice.invoice_date <= report_data.end_date,
            Invoice.is_active == True
        ).all()

        total_purchases = sum(invoice.total_amount for invoice in purchases)
        total_tax = sum(invoice.tax_amount for invoice in purchases)

        return {
            "total_purchases": total_purchases,
            "total_tax": total_tax,
            "invoice_count": len(purchases),
            "purchases_data": purchases
        }

    def get_gst_report(self, report_data: GSTReport) -> dict:
        gst_records = self.db.query(GST).filter(
            GST.company_id == report_data.company_id,
            GST.gst_type == report_data.gst_type,
            GST.created_at >= report_data.start_date,
            GST.created_at <= report_data.end_date
        ).all()

        total_taxable = sum(gst.taxable_amount for gst in gst_records)
        total_cgst = sum(gst.cgst_amount for gst in gst_records)
        total_sgst = sum(gst.sgst_amount for gst in gst_records)
        total_igst = sum(gst.igst_amount for gst in gst_records)
        total_gst = total_cgst + total_sgst + total_igst

        return {
            "total_taxable": total_taxable,
            "total_cgst": total_cgst,
            "total_sgst": total_sgst,
            "total_igst": total_igst,
            "total_gst": total_gst,
            "gst_records": gst_records
        }

    def get_trial_balance(self, report_data: TrialBalanceReport) -> dict:
        # This would query ledger entries and calculate balances
        # For simplicity, returning mock data
        return {
            "total_debit": 100000.0,
            "total_credit": 100000.0,
            "difference": 0.0,
            "ledger_entries": []
        }

    def get_profit_loss(self, report_data: ProfitLossReport) -> dict:
        # This would calculate profit and loss
        # For simplicity, returning mock data
        return {
            "total_income": 500000.0,
            "total_expenses": 300000.0,
            "net_profit": 200000.0,
            "profit_loss_items": []
        }
