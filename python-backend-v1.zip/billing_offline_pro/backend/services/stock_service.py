
from typing import List, Optional
from datetime import datetime

from sqlalchemy.orm import Session

from backend.models.stock import Stock
from backend.models.product import Product
from backend.models.stock_movement import StockMovement
from backend.core.database import get_db

class StockService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def get_stock(self, product_id: int) -> Optional[Stock]:
        return self.db.query(Stock).filter(Stock.product_id == product_id).first()

    def get_all_stock(self, company_id: int) -> List[Stock]:
        return self.db.query(Stock).join(Product).filter(
            Product.company_id == company_id
        ).all()

    def update_stock(self, product_id: int, quantity: float, value: float, movement_type: str, reference_id: int = None):
        stock = self.get_stock(product_id)
        if not stock:
            return None

        # Create stock movement record
        movement = StockMovement(
            stock_id=stock.id,
            product_id=product_id,
            movement_type=movement_type,
            quantity=quantity,
            value=value,
            reference_id=reference_id
        )
        self.db.add(movement)

        # Update stock
        if movement_type == "in":
            stock.quantity += quantity
            stock.value += value
        elif movement_type == "out":
            stock.quantity -= quantity
            stock.value -= value

        self.db.commit()
        return stock

    def get_stock_movements(self, stock_id: int, skip: int = 0, limit: int = 100) -> List[StockMovement]:
        return self.db.query(StockMovement).filter(
            StockMovement.stock_id == stock_id
        ).order_by(StockMovement.created_at.desc()).offset(skip).limit(limit).all()
