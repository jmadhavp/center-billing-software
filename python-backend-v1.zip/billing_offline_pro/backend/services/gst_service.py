
from typing import List, Optional
from datetime import datetime

from sqlalchemy.orm import Session

from backend.models.gst import GST
from backend.models.invoice import Invoice
from backend.core.database import get_db

class GSTService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def calculate_gst(self, invoice: Invoice) -> dict:
        gst_details = {
            "taxable_amount": invoice.subtotal - invoice.discount_amount,
            "cgst_amount": 0.0,
            "sgst_amount": 0.0,
            "igst_amount": 0.0,
            "total_amount": invoice.total_amount
        }

        # Determine GST type based on company and customer state
        if invoice.invoice_type == "sale":
            if invoice.customer and invoice.customer.state == "Maharashtra":  # Same state
                gst_details["cgst_amount"] = invoice.tax_amount / 2
                gst_details["sgst_amount"] = invoice.tax_amount / 2
            else:  # Interstate
                gst_details["igst_amount"] = invoice.tax_amount

        return gst_details

    def create_gst_record(self, invoice: Invoice) -> GST:
        gst_details = self.calculate_gst(invoice)

        gst_record = GST(
            gstn_year=f"{invoice.invoice_date.year}",
            gstn_month=invoice.invoice_date.strftime("%B"),
            gst_type=invoice.invoice_type,
            taxable_amount=gst_details["taxable_amount"],
            cgst_amount=gst_details["cgst_amount"],
            sgst_amount=gst_details["sgst_amount"],
            igst_amount=gst_details["igst_amount"],
            total_amount=gst_details["total_amount"],
            company_id=invoice.company_id
        )

        self.db.add(gst_record)
        self.db.commit()
        self.db.refresh(gst_record)
        return gst_record

    def get_gst_reports(self, company_id: int, start_date: datetime, end_date: datetime, gst_type: str = "sales") -> List[GST]:
        return self.db.query(GST).filter(
            GST.company_id == company_id,
            GST.gst_type == gst_type,
            GST.created_at >= start_date,
            GST.created_at <= end_date
        ).all()
