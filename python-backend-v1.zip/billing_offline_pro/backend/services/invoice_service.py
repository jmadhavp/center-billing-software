
from typing import List, Optional
from datetime import datetime

from sqlalchemy.orm import Session

from backend.models.invoice import Invoice, InvoiceItem
from backend.models.product import Product
from backend.models.customer import Customer
from backend.models.supplier import Supplier
from backend.schemas.invoice import InvoiceCreate, InvoiceUpdate, InvoiceItemCreate
from backend.core.database import get_db

class InvoiceService:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def create_invoice(self, invoice_data: InvoiceCreate, company_id: int) -> Invoice:
        invoice = Invoice(
            invoice_number=self._generate_invoice_number(company_id),
            invoice_date=invoice_data.invoice_date,
            due_date=invoice_data.due_date,
            invoice_type=invoice_data.invoice_type,
            status=invoice_data.status,
            subtotal=invoice_data.subtotal,
            discount_amount=invoice_data.discount_amount,
            tax_amount=invoice_data.tax_amount,
            total_amount=invoice_data.total_amount,
            notes=invoice_data.notes,
            terms=invoice_data.terms,
            company_id=company_id,
            customer_id=invoice_data.customer_id,
            supplier_id=invoice_data.supplier_id
        )
        self.db.add(invoice)
        self.db.commit()
        self.db.refresh(invoice)

        for item_data in invoice_data.items:
            item = InvoiceItem(
                invoice_id=invoice.id,
                product_id=item_data.product_id,
                description=item_data.description,
                quantity=item_data.quantity,
                unit_price=item_data.unit_price,
                discount_percent=item_data.discount_percent,
                tax_rate=item_data.tax_rate,
                total_amount=item_data.quantity * item_data.unit_price
            )
            self.db.add(item)

            # Update stock if it's a sale
            if invoice.invoice_type == "sale" and item_data.product_id:
                product = self.db.query(Product).filter(Product.id == item_data.product_id).first()
                if product:
                    product.stock.quantity -= item_data.quantity
                    product.stock.value -= (item_data.quantity * product.cost_price)

        self.db.commit()
        self.db.refresh(invoice)
        return invoice

    def get_invoice(self, invoice_id: int, company_id: int) -> Optional[Invoice]:
        return self.db.query(Invoice).filter(
            Invoice.id == invoice_id,
            Invoice.company_id == company_id,
            Invoice.is_active == True
        ).first()

    def get_invoices(self, company_id: int, skip: int = 0, limit: int = 100) -> List[Invoice]:
        return self.db.query(Invoice).filter(
            Invoice.company_id == company_id,
            Invoice.is_active == True
        ).order_by(Invoice.created_at.desc()).offset(skip).limit(limit).all()

    def update_invoice(self, invoice_id: int, invoice_data: InvoiceUpdate, company_id: int) -> Optional[Invoice]:
        invoice = self.get_invoice(invoice_id, company_id)
        if not invoice:
            return None

        update_data = invoice_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(invoice, field, value)

        self.db.commit()
        self.db.refresh(invoice)
        return invoice

    def delete_invoice(self, invoice_id: int, company_id: int) -> bool:
        invoice = self.get_invoice(invoice_id, company_id)
        if not invoice:
            return False

        invoice.is_active = False
        self.db.commit()
        return True

    def _generate_invoice_number(self, company_id: int) -> str:
        # Simple invoice number generation: COMP000001
        last_invoice = self.db.query(Invoice).filter(
            Invoice.company_id == company_id
        ).order_by(Invoice.id.desc()).first()

        if last_invoice:
            last_number = int(last_invoice.invoice_number.split('COMP')[-1])
            new_number = last_number + 1
        else:
            new_number = 1

        return f"COMP{new_number:06d}"
