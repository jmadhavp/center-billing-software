
from typing import Optional

from pydantic import BaseModel

class SupplierBase(BaseModel):
    name: str
    gstin: Optional[str] = None
    pan: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None

class SupplierCreate(SupplierBase):
    pass

class SupplierUpdate(SupplierBase):
    pass

class Supplier(SupplierBase):
    id: int
    is_active: bool
    created_at: str
    updated_at: str
    company_id: int

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }
