
from typing import List, Optional
from datetime import datetime

class ReportBase(BaseModel):
    start_date: datetime
    end_date: datetime
    company_id: int

class SalesReport(ReportBase):
    pass

class PurchaseReport(ReportBase):
    pass

class GSTReport(ReportBase):
    gst_type: str = "sales"  # sales or purchase

class TrialBalanceReport(ReportBase):
    pass

class ProfitLossReport(ReportBase):
    pass

class ReportData(BaseModel):
    total_sales: float
    total_purchases: float
    total_tax: float
    net_profit: float
    total_receipts: float
    total_payments: float
