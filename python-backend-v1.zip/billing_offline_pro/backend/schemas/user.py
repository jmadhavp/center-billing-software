
from typing import Optional

from pydantic import BaseModel, EmailStr

class UserBase(BaseModel):
    username: str
    email: EmailStr
    full_name: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None

class UserInDBBase(UserBase):
    id: Optional[int] = None
    is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }

class User(UserInDBBase):
    pass

class UserInDB(UserInDBBase):
    hashed_password: str
