
from typing import Optional

from pydantic import BaseModel
from datetime import datetime

class PaymentBase(BaseModel):
    payment_number: str
    payment_date: datetime
    payment_type: str = "receipt"
    amount: float
    payment_method: str = "cash"
    reference_number: Optional[str] = None
    notes: Optional[str] = None
    invoice_id: Optional[int] = None
    customer_id: Optional[int] = None
    supplier_id: Optional[int] = None

class PaymentCreate(PaymentBase):
    pass

class PaymentUpdate(BaseModel):
    payment_date: Optional[datetime] = None
    payment_type: Optional[str] = None
    amount: Optional[float] = None
    payment_method: Optional[str] = None
    reference_number: Optional[str] = None
    notes: Optional[str] = None
    invoice_id: Optional[int] = None
    customer_id: Optional[int] = None
    supplier_id: Optional[int] = None

class Payment(PaymentBase):
    id: int
    is_active: bool
    created_at: str
    updated_at: str
    company_id: int

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }
