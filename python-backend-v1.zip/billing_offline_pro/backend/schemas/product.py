
from typing import Optional

from pydantic import BaseModel

class ProductBase(BaseModel):
    name: str
    hsn_code: Optional[str] = None
    sku: Optional[str] = None
    description: Optional[str] = None
    unit: Optional[str] = None
    price: Optional[float] = None
    cost_price: Optional[float] = None
    tax_rate: Optional[float] = None

class ProductCreate(ProductBase):
    pass

class ProductUpdate(ProductBase):
    pass

class Product(ProductBase):
    id: int
    is_active: bool
    created_at: str
    updated_at: str
    company_id: int

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }
