
from typing import List, Optional

from pydantic import BaseModel, Field
from datetime import datetime

class InvoiceItemBase(BaseModel):
    product_id: Optional[int] = None
    description: str
    quantity: float
    unit_price: float
    discount_percent: float = 0.0
    tax_rate: float = 0.0

class InvoiceItemCreate(InvoiceItemBase):
    pass

class InvoiceItem(InvoiceItemBase):
    id: int
    total_amount: float
    created_at: str

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }

class InvoiceBase(BaseModel):
    invoice_number: str
    invoice_date: datetime
    due_date: Optional[datetime] = None
    invoice_type: str = "sale"
    status: str = "draft"
    subtotal: float = 0.0
    discount_amount: float = 0.0
    tax_amount: float = 0.0
    total_amount: float = 0.0
    notes: Optional[str] = None
    terms: Optional[str] = None
    customer_id: Optional[int] = None
    supplier_id: Optional[int] = None

class InvoiceCreate(InvoiceBase):
    items: List[InvoiceItemCreate] = []

class InvoiceUpdate(BaseModel):
    invoice_date: Optional[datetime] = None
    due_date: Optional[datetime] = None
    status: Optional[str] = None
    subtotal: Optional[float] = None
    discount_amount: Optional[float] = None
    tax_amount: Optional[float] = None
    total_amount: Optional[float] = None
    notes: Optional[str] = None
    terms: Optional[str] = None
    customer_id: Optional[int] = None
    supplier_id: Optional[int] = None

class Invoice(InvoiceBase):
    id: int
    is_active: bool
    created_at: str
    updated_at: str
    company_id: int
    customer: Optional[dict] = None
    supplier: Optional[dict] = None
    items: List[InvoiceItem] = []

    class Config:
        from sqlalchemy import DateTime
        from datetime import datetime
        json_encoders = {
            DateTime: lambda v: v.isoformat() if v else None
        }
