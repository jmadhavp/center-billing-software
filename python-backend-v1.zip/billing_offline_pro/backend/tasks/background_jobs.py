
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.models.invoice import Invoice
from backend.models.payment import Payment

class BackgroundJobs:
    def __init__(self, db: Session = Depends(get_db)):
        self.db = db

    def send_due_reminders(self):
        # Find invoices that are due within the next 3 days
        due_date = datetime.now() + timedelta(days=3)
        due_invoices = self.db.query(Invoice).filter(
            Invoice.due_date <= due_date,
            Invoice.status != "paid"
        ).all()

        for invoice in due_invoices:
            # Send reminder logic here
            print(f"Reminder sent for invoice {invoice.invoice_number}")

    def process_pending_payments(self):
        # Process any pending payments
        pending_payments = self.db.query(Payment).filter(
            Payment.status == "pending"
        ).all()

        for payment in pending_payments:
            # Process payment logic here
            print(f"Processing payment {payment.payment_number}")

    def cleanup_old_data(self):
        # Clean up old data (e.g., logs older than 1 year)
        one_year_ago = datetime.now() - timedelta(days=365)
        # Add cleanup logic here
        print("Cleanup completed")
