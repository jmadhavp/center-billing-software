
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.payment import Payment
from backend.schemas.payment import PaymentCreate, Payment as PaymentSchema

router = APIRouter()

@router.get("/", response_model=list[PaymentSchema])
def get_payments(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    payments = db.query(Payment).filter(
        Payment.company_id == company_id,
        Payment.is_active == True
    ).all()
    return payments

@router.post("/", response_model=PaymentSchema)
def create_payment(payment: PaymentCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_payment = Payment(**payment.dict(), company_id=company_id)
    db.add(db_payment)
    db.commit()
    db.refresh(db_payment)
    return db_payment

@router.get("/{payment_id}", response_model=PaymentSchema)
def get_payment(payment_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    payment = db.query(Payment).filter(
        Payment.id == payment_id,
        Payment.company_id == company_id,
        Payment.is_active == True
    ).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment

@router.put("/{payment_id}", response_model=PaymentSchema)
def update_payment(payment_id: int, payment: PaymentCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_payment = db.query(Payment).filter(
        Payment.id == payment_id,
        Payment.company_id == company_id
    ).first()
    if not db_payment:
        raise HTTPException(status_code=404, detail="Payment not found")

    update_data = payment.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_payment, field, value)

    db.commit()
    db.refresh(db_payment)
    return db_payment

@router.delete("/{payment_id}")
def delete_payment(payment_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_payment = db.query(Payment).filter(
        Payment.id == payment_id,
        Payment.company_id == company_id
    ).first()
    if not db_payment:
        raise HTTPException(status_code=404, detail="Payment not found")

    db_payment.is_active = False
    db.commit()
    return {"message": "Payment deleted successfully"}
