
from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.user import User

def get_current_active_user(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
):
    user = get_current_active_user(db, token)
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return user

def get_current_company(
    current_user: User = Depends(get_current_active_user)
):
    # In a multi-company setup, you'd get the current company
    # For now, returning a default
    return 1

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
