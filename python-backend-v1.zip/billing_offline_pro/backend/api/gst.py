
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.gst import GST
from backend.schemas.reports import GSTReport
from backend.services.gst_service import GSTService

router = APIRouter()

@router.get("/", response_model=list[GST])
def get_gst_reports(start_date: str, end_date: str, gst_type: str = "sales", db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = GSTReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id,
        gst_type=gst_type
    )
    service = GSTService(db)
    return service.get_gst_reports(report_data.company_id, report_data.start_date, report_data.end_date, report_data.gst_type)

@router.get("/summary", response_model=dict)
def get_gst_summary(start_date: str, end_date: str, gst_type: str = "sales", db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = GSTReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id,
        gst_type=gst_type
    )
    service = GSTService(db)
    gst_records = service.get_gst_reports(report_data.company_id, report_data.start_date, report_data.end_date, report_data.gst_type)

    total_taxable = sum(gst.taxable_amount for gst in gst_records)
    total_cgst = sum(gst.cgst_amount for gst in gst_records)
    total_sgst = sum(gst.sgst_amount for gst in gst_records)
    total_igst = sum(gst.igst_amount for gst in gst_records)
    total_gst = total_cgst + total_sgst + total_igst

    return {
        "total_taxable": total_taxable,
        "total_cgst": total_cgst,
        "total_sgst": total_sgst,
        "total_igst": total_igst,
        "total_gst": total_gst,
        "gst_type": gst_type,
        "records_count": len(gst_records)
    }
