
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.supplier import Supplier
from backend.schemas.supplier import SupplierCreate, Supplier as SupplierSchema

router = APIRouter()

@router.get("/", response_model=list[SupplierSchema])
def get_suppliers(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    suppliers = db.query(Supplier).filter(
        Supplier.company_id == company_id,
        Supplier.is_active == True
    ).all()
    return suppliers

@router.post("/", response_model=SupplierSchema)
def create_supplier(supplier: SupplierCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_supplier = Supplier(**supplier.dict(), company_id=company_id)
    db.add(db_supplier)
    db.commit()
    db.refresh(db_supplier)
    return db_supplier

@router.get("/{supplier_id}", response_model=SupplierSchema)
def get_supplier(supplier_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    supplier = db.query(Supplier).filter(
        Supplier.id == supplier_id,
        Supplier.company_id == company_id,
        Supplier.is_active == True
    ).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return supplier

@router.put("/{supplier_id}", response_model=SupplierSchema)
def update_supplier(supplier_id: int, supplier: SupplierCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_supplier = db.query(Supplier).filter(
        Supplier.id == supplier_id,
        Supplier.company_id == company_id
    ).first()
    if not db_supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")

    update_data = supplier.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_supplier, field, value)

    db.commit()
    db.refresh(db_supplier)
    return db_supplier

@router.delete("/{supplier_id}")
def delete_supplier(supplier_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_supplier = db.query(Supplier).filter(
        Supplier.id == supplier_id,
        Supplier.company_id == company_id
    ).first()
    if not db_supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")

    db_supplier.is_active = False
    db.commit()
    return {"message": "Supplier deleted successfully"}
