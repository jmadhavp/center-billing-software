
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.company import Company
from backend.schemas.company import CompanyCreate, Company as CompanySchema

router = APIRouter()

@router.get("/", response_model=list[CompanySchema])
def get_companies(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    companies = db.query(Company).filter(Company.owner_id == current_user.id).all()
    return companies

@router.post("/", response_model=CompanySchema)
def create_company(company: CompanyCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    db_company = Company(**company.dict(), owner_id=current_user.id)
    db.add(db_company)
    db.commit()
    db.refresh(db_company)
    return db_company

@router.get("/{company_id}", response_model=CompanySchema)
def get_company(company_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    company = db.query(Company).filter(
        Company.id == company_id,
        Company.owner_id == current_user.id
    ).first()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company

@router.put("/{company_id}", response_model=CompanySchema)
def update_company(company_id: int, company: CompanyCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    db_company = db.query(Company).filter(
        Company.id == company_id,
        Company.owner_id == current_user.id
    ).first()
    if not db_company:
        raise HTTPException(status_code=404, detail="Company not found")

    update_data = company.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_company, field, value)

    db.commit()
    db.refresh(db_company)
    return db_company

@router.delete("/{company_id}")
def delete_company(company_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    db_company = db.query(Company).filter(
        Company.id == company_id,
        Company.owner_id == current_user.id
    ).first()
    if not db_company:
        raise HTTPException(status_code=404, detail="Company not found")

    db_company.is_active = False
    db.commit()
    return {"message": "Company deleted successfully"}
