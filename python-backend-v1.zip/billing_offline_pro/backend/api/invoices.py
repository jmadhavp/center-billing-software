
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.invoice import Invoice
from backend.schemas.invoice import InvoiceCreate, Invoice as InvoiceSchema
from backend.services.invoice_service import InvoiceService

router = APIRouter()

@router.get("/", response_model=list[InvoiceSchema])
def get_invoices(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    service = InvoiceService(db)
    return service.get_invoices(company_id)

@router.post("/", response_model=InvoiceSchema)
def create_invoice(invoice: InvoiceCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    service = InvoiceService(db)
    return service.create_invoice(invoice, company_id)

@router.get("/{invoice_id}", response_model=InvoiceSchema)
def get_invoice(invoice_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    service = InvoiceService(db)
    invoice = service.get_invoice(invoice_id, company_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return invoice

@router.put("/{invoice_id}", response_model=InvoiceSchema)
def update_invoice(invoice_id: int, invoice: InvoiceCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    service = InvoiceService(db)
    updated_invoice = service.update_invoice(invoice_id, invoice, company_id)
    if not updated_invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return updated_invoice

@router.delete("/{invoice_id}")
def delete_invoice(invoice_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    service = InvoiceService(db)
    if not service.delete_invoice(invoice_id, company_id):
        raise HTTPException(status_code=404, detail="Invoice not found")
    return {"message": "Invoice deleted successfully"}
