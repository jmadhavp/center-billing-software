
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.invoice import Invoice
from backend.schemas.reports import SalesReport, PurchaseReport, TrialBalanceReport, ProfitLossReport
from backend.services.report_service import ReportService

router = APIRouter()

@router.get("/sales", response_model=dict)
def get_sales_report(start_date: str, end_date: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = SalesReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id
    )
    service = ReportService(db)
    return service.get_sales_report(report_data)

@router.get("/purchases", response_model=dict)
def get_purchase_report(start_date: str, end_date: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = PurchaseReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id
    )
    service = ReportService(db)
    return service.get_purchase_report(report_data)

@router.get("/trial-balance", response_model=dict)
def get_trial_balance(start_date: str, end_date: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = TrialBalanceReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id
    )
    service = ReportService(db)
    return service.get_trial_balance(report_data)

@router.get("/profit-loss", response_model=dict)
def get_profit_loss(start_date: str, end_date: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from datetime import datetime
    report_data = ProfitLossReport(
        start_date=datetime.fromisoformat(start_date),
        end_date=datetime.fromisoformat(end_date),
        company_id=company_id
    )
    service = ReportService(db)
    return service.get_profit_loss(report_data)
