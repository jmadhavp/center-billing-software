
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user

router = APIRouter()

@router.get("/backup")
def get_backup(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from backend.services.backup_service import BackupService
    service = BackupService(db)
    return service.list_backups()

@router.post("/backup")
def create_backup(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from backend.services.backup_service import BackupService
    service = BackupService(db)
    backup_path = service.create_backup()
    return {"message": "Backup created successfully", "backup_path": backup_path}

@router.post("/restore")
def restore_backup(backup_name: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    from backend.services.backup_service import BackupService
    service = BackupService(db)
    if service.restore_backup(backup_name):
        return {"message": "Backup restored successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to restore backup")
