
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.core.database import get_db
from backend.core.security import get_current_active_user
from backend.models.product import Product
from backend.schemas.product import ProductCreate, Product as ProductSchema

router = APIRouter()

@router.get("/", response_model=list[ProductSchema])
def get_products(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    products = db.query(Product).filter(
        Product.company_id == company_id,
        Product.is_active == True
    ).all()
    return products

@router.post("/", response_model=ProductSchema)
def create_product(product: ProductCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_product = Product(**product.dict(), company_id=company_id)
    db.add(db_product)
    db.commit()
    db.refresh(db_product)

    # Create stock record
    stock = Stock(
        product_id=db_product.id,
        quantity=0.0,
        value=0.0
    )
    db.add(stock)
    db.commit()

    return db_product

@router.get("/{product_id}", response_model=ProductSchema)
def get_product(product_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    product = db.query(Product).filter(
        Product.id == product_id,
        Product.company_id == company_id,
        Product.is_active == True
    ).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

@router.put("/{product_id}", response_model=ProductSchema)
def update_product(product_id: int, product: ProductCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_product = db.query(Product).filter(
        Product.id == product_id,
        Product.company_id == company_id
    ).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    update_data = product.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_product, field, value)

    db.commit()
    db.refresh(db_product)
    return db_product

@router.delete("/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user), company_id: int = Depends(get_current_company)):
    db_product = db.query(Product).filter(
        Product.id == product_id,
        Product.company_id == company_id
    ).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Product not found")

    db_product.is_active = False
    db.commit()
    return {"message": "Product deleted successfully"}
