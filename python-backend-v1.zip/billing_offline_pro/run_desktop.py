
import webview
from threading import Thread
import subprocess
import sys
import os

def start_backend():
    # Start the FastAPI backend in a separate process
    cmd = [sys.executable, "app.py"]
    subprocess.Popen(cmd, cwd=os.path.dirname(os.path.abspath(__file__)))

def start_frontend():
    # Create the desktop window
    window = webview.create_window(
        'Billing Offline Pro',
        'http://127.0.0.1:8000',
        width=1200,
        height=800,
        resizable=True,
        fullscreen=False,
        min_size=(1024, 768),
        confirm_close=True
    )
    webview.start(gui='cef', debug=True)

if __name__ == '__main__':
    # Start backend in a separate thread
    backend_thread = Thread(target=start_backend)
    backend_thread.daemon = True
    backend_thread.start()

    # Give backend some time to start
    import time
    time.sleep(2)

    # Start the desktop frontend
    start_frontend()
