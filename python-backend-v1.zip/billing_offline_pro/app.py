
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from backend.core.config import settings
from backend.core.database import engine, get_db
from backend.core.security import get_current_user
from backend.models.user import User
from backend.api import auth, company, customers, suppliers, products, invoices, payments, reports, gst, settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Offline Billing and Accounting Software",
    version="1.0.0"
)

# Allow all origins for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(company.router, prefix="/api/company", tags=["company"])
app.include_router(customers.router, prefix="/api/customers", tags=["customers"])
app.include_router(suppliers.router, prefix="/api/suppliers", tags=["suppliers"])
app.include_router(products.router, prefix="/api/products", tags=["products"])
app.include_router(invoices.router, prefix="/api/invoices", tags=["invoices"])
app.include_router(payments.router, prefix="/api/payments", tags=["payments"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])
app.include_router(gst.router, prefix="/api/gst", tags=["gst"])
app.include_router(settings.router, prefix="/api/settings", tags=["settings"])

@app.get("/")
def read_root():
    return {"message": "Billing Offline Pro API"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}

@app.get("/api/users/me", response_model=User)
def read_users_me(current_user: User = Depends(get_current_user)):
    return current_user

@app.middleware("http")
async def db_session_middleware(request, call_next):
    response = None
    try:
        request.state.db = Session(bind=engine)
        response = await call_next(request)
    finally:
        request.state.db.close()
    return response

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
