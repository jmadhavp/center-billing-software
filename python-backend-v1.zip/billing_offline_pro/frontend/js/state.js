
class State {
    constructor() {
        this.state = {
            currentUser: null,
            currentCompany: null,
            customers: [],
            suppliers: [],
            products: [],
            invoices: [],
            payments: [],
            loading: false
        };
    }

    get(key) {
        return this.state[key];
    }

    set(key, value) {
        this.state[key] = value;
        this._saveToLocalStorage();
    }

    update(key, updater) {
        this.state[key] = updater(this.state[key]);
        this._saveToLocalStorage();
    }

    setLoading(loading) {
        this.set('loading', loading);
    }

    setCurrentUser(user) {
        this.set('currentUser', user);
        localStorage.setItem('authToken', user.access_token);
    }

    getCurrentUser() {
        return this.get('currentUser');
    }

    setCurrentCompany(company) {
        this.set('currentCompany', company);
        localStorage.setItem('currentCompany', JSON.stringify(company));
    }

    getCurrentCompany() {
        return this.get('currentCompany');
    }

    async fetchCustomers() {
        try {
            this.setLoading(true);
            const customers = await api.get('/customers');
            this.set('customers', customers);
            return customers;
        } catch (error) {
            console.error('Error fetching customers:', error);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async fetchSuppliers() {
        try {
            this.setLoading(true);
            const suppliers = await api.get('/suppliers');
            this.set('suppliers', suppliers);
            return suppliers;
        } catch (error) {
            console.error('Error fetching suppliers:', error);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async fetchProducts() {
        try {
            this.setLoading(true);
            const products = await api.get('/products');
            this.set('products', products);
            return products;
        } catch (error) {
            console.error('Error fetching products:', error);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async fetchInvoices() {
        try {
            this.setLoading(true);
            const invoices = await api.get('/invoices');
            this.set('invoices', invoices);
            return invoices;
        } catch (error) {
            console.error('Error fetching invoices:', error);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async fetchPayments() {
        try {
            this.setLoading(true);
            const payments = await api.get('/payments');
            this.set('payments', payments);
            return payments;
        } catch (error) {
            console.error('Error fetching payments:', error);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    logout() {
        this.set('currentUser', null);
        this.set('currentCompany', null);
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentCompany');
    }

    _saveToLocalStorage() {
        Object.keys(this.state).forEach(key => {
            if (key !== 'loading') {
                localStorage.setItem(`appState_${key}`, JSON.stringify(this.state[key]));
            }
        });
    }

    _loadFromLocalStorage() {
        Object.keys(this.state).forEach(key => {
            const stored = localStorage.getItem(`appState_${key}`);
            if (stored) {
                try {
                    this.state[key] = JSON.parse(stored);
                } catch (error) {
                    console.warn(`Error parsing stored state for ${key}:`, error);
                }
            }
        });

        // Load auth token
        const token = localStorage.getItem('authToken');
        if (token) {
            this.state.currentUser = { access_token: token };
        }

        // Load current company
        const currentCompany = localStorage.getItem('currentCompany');
        if (currentCompany) {
            this.state.currentCompany = JSON.parse(currentCompany);
        }
    }
}

export const state = new State();
state._loadFromLocalStorage();
