
export function showAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '10000';
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

export function hideAlert() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => alert.remove());
}

export function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

export function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

export function validateEmail(email) {
    const re = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    return re.test(email);
}

export function validateGSTIN(gstin) {
    const re = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}[Z]{1}[A-Z0-9]{1}$/;
    return re.test(gstin);
}

export function validatePAN(pan) {
    const re = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return re.test(pan);
}

export function formatGSTIN(gstin) {
    return gstin.toUpperCase();
}

export function formatPAN(pan) {
    return pan.toUpperCase();
}

export function formatPhoneNumber(phone) {
    return phone.replace(/\D/g, '').slice(0, 10);
}

export function formatInvoiceNumber(number) {
    return `INV${number.toString().padStart(6, '0')}`;
}

export function calculateTaxAmount(amount, taxRate) {
    return amount * (taxRate / 100);
}

export function calculateTotal(amount, taxRate, discount = 0) {
    const taxAmount = calculateTaxAmount(amount, taxRate);
    return (amount - discount) + taxAmount;
}

export function generateInvoicePDF(invoiceData) {
    // This would generate a PDF using a library like jsPDF
    console.log('Generating PDF for invoice:', invoiceData);
    showAlert('success', 'PDF generated successfully');
}

export function exportToExcel(data, filename = 'export') {
    // This would export data to Excel format
    console.log('Exporting to Excel:', data);
    showAlert('success', 'Data exported successfully');
}

export function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

export function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

export function closeModalOnClickOutside(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        window.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
}

export function formatAddress(address) {
    if (!address) return '';
    return address.replace(/(?:\r\\n|\\r|\\n)/g, '<br>');
}

export function calculateSubTotal(items) {
    return items.reduce((total, item) => total + (item.quantity * item.unit_price), 0);
}

export function calculateDiscount(subTotal, discountPercent) {
    return subTotal * (discountPercent / 100);
}

export function calculateTax(subTotal, taxRate) {
    return subTotal * (taxRate / 100);
}

export function formatQuantity(quantity) {
    return quantity.toFixed(2);
}

export function formatNumber(number) {
    return new Intl.NumberFormat('en-IN').format(number);
}

export function getAge(birthDate) {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    return age;
}

export function sortArray(array, key, order = 'asc') {
    return array.sort((a, b) => {
        if (order === 'asc') {
            return a[key] > b[key] ? 1 : -1;
        } else {
            return a[key] < b[key] ? 1 : -1;
        }
    });
}

export function filterArray(array, filterFn) {
    return array.filter(filterFn);
}

export function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

export function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}
