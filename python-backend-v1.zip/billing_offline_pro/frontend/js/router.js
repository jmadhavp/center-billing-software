
class Router {
    constructor() {
        this.routes = [];
        this.currentRoute = null;
        this.routeChangeListeners = [];

        window.addEventListener('popstate', () => {
            this.handleRouteChange();
        });
    }

    add(route, handler) {
        this.routes.push({ route, handler });
    }

    navigate(path, state = {}) {
        window.history.pushState(state, '', path);
        this.handleRouteChange();
    }

    replace(path, state = {}) {
        window.history.replaceState(state, '', path);
        this.handleRouteChange();
    }

    goBack() {
        window.history.back();
    }

    goForward() {
        window.history.forward();
    }

    handleRouteChange() {
        const path = window.location.pathname;
        const route = this.routes.find(r => this.matchRoute(r.route, path));

        if (route) {
            this.currentRoute = route;
            route.handler(this.extractParams(route.route, path));
            this.notifyRouteChange();
        } else {
            this.handleNotFound();
        }
    }

    matchRoute(route, path) {
        const routeRegex = this.routeToRegex(route);
        return routeRegex.test(path);
    }

    extractParams(route, path) {
        const routeRegex = this.routeToRegex(route);
        const match = path.match(routeRegex);
        if (!match) return {};

        const paramNames = route.match(/:\w+/g) || [];
        return paramNames.reduce((params, param, index) => {
            params[param.substring(1)] = match[index + 1];
            return params;
        }, {});
    }

    routeToRegex(route) {
        return new RegExp('^' + route.replace(/:\w+/g, '([^/]+)') + '$');
    }

    notifyRouteChange() {
        this.routeChangeListeners.forEach(listener => listener(this.currentRoute));
    }

    onRouteChange(callback) {
        this.routeChangeListeners.push(callback);
    }

    handleNotFound() {
        console.warn('Route not found:', window.location.pathname);
        // You could render a 404 page here
    }
}

export const router = new Router();
