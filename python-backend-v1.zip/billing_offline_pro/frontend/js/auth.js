
import { state, api } from './state.js';
import { router } from './router.js';
import { showAlert, hideAlert } from './utils.js';

class Auth {
    async login(username, password) {
        try {
            state.setLoading(true);
            const response = await api.post('/auth/token', {
                username,
                password,
                grant_type: 'password'
            });
            state.setCurrentUser(response);
            router.navigate('/dashboard');
            return response;
        } catch (error) {
            showAlert('error', error.message);
            throw error;
        } finally {
            state.setLoading(false);
        }
    }

    async register(userData) {
        try {
            state.setLoading(true);
            const response = await api.post('/auth/users/', userData);
            await this.login(userData.username, userData.password);
            return response;
        } catch (error) {
            showAlert('error', error.message);
            throw error;
        } finally {
            state.setLoading(false);
        }
    }

    logout() {
        state.logout();
        router.navigate('/login');
    }

    async checkAuth() {
        try {
            state.setLoading(true);
            const response = await api.get('/auth/users/me');
            state.setCurrentUser(response);
            return response;
        } catch (error) {
            state.logout();
            router.navigate('/login');
        } finally {
            state.setLoading(false);
        }
    }
}

export const auth = new Auth();
