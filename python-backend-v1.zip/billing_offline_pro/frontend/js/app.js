
import { state } from './state.js';
import { router } from './router.js';
import { auth } from './auth.js';
import { showAlert, hideAlert } from './utils.js';

// Initialize app
document.addEventListener('DOMContentLoaded', async () => {
    // Check authentication on load
    await auth.checkAuth();

    // Set up routing
    setupRoutes();

    // Handle initial route
    router.handleRouteChange();

    // Set up mobile menu toggle
    setupMobileMenu();
});

function setupRoutes() {
    router.add('/login', renderLoginPage);
    router.add('/register', renderRegisterPage);
    router.add('/dashboard', renderDashboardPage);
    router.add('/companies', renderCompaniesPage);
    router.add('/customers', renderCustomersPage);
    router.add('/suppliers', renderSuppliersPage);
    router.add('/products', renderProductsPage);
    router.add('/invoices', renderInvoicesPage);
    router.add('/payments', renderPaymentsPage);
    router.add('/reports', renderReportsPage);
    router.add('/settings', renderSettingsPage);

    // Invoice-related routes
    router.add('/invoice/create', renderCreateInvoicePage);
    router.add('/invoice/:id', renderInvoiceDetailPage);
}

function setupMobileMenu() {
    const toggle = document.querySelector('.mobile-menu-toggle');
    const sidebar = document.querySelector('.sidebar');

    if (toggle && sidebar) {
        toggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }
}

// Page renderers
async function renderLoginPage() {
    if (state.getCurrentUser()) {
        router.navigate('/dashboard');
        return;
    }

    document.getElementById('app').innerHTML = `
        <div class="main-content">
            <div class="card">
                <div class="card-header">
                    <h2>Login</h2>
                </div>
                <div class="card-body">
                    <form id="login-form">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                        <a href="#/register" class="btn btn-secondary">Register</a>
                    </form>
                </div>
            </div>
        </div>
    `;

    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        await auth.login(username, password);
    });
}

async function renderRegisterPage() {
    document.getElementById('app').innerHTML = `
        <div class="main-content">
            <div class="card">
                <div class="card-header">
                    <h2>Register</h2>
                </div>
                <div class="card-body">
                    <form id="register-form">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" id="full_name" name="full_name" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Register</button>
                        <a href="#/login" class="btn btn-secondary">Back to Login</a>
                    </form>
                </div>
            </div>
        </div>
    `;

    document.getElementById('register-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const fullName = document.getElementById('full_name').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;

        if (password !== confirmPassword) {
            showAlert('error', 'Passwords do not match');
            return;
        }

        await auth.register({
            username,
            email,
            full_name: fullName,
            password
        });
    });
}

async function renderDashboardPage() {
    if (!state.getCurrentUser()) {
        router.navigate('/login');
        return;
    }

    document.getElementById('app').innerHTML = `
        <div class="main-content">
            <div class="header">
                <h1>Dashboard</h1>
                <div>
                    <button class="btn btn-secondary" onclick="auth.logout()">Logout</button>
                </div>
            </div>

            <div class="breadcrumb">
                <a href="#/dashboard">Home</a>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value" id="total-customers">0</div>
                    <div class="stat-label">Total Customers</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="total-suppliers">0</div>
                    <div class="stat-label">Total Suppliers</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="total-products">0</div>
                    <div class="stat-label">Total Products</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="total-invoices">0</div>
                    <div class="stat-label">Total Invoices</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>Recent Invoices</h3>
                </div>
                <div class="card-body">
                    <table class="table" id="recent-invoices">
                        <thead>
                            <tr>
                                <th>Invoice No</th>
                                <th>Date</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Invoices will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;

    // Load dashboard data
    await loadDashboardData();
}

async function renderCompaniesPage() {
    if (!state.getCurrentUser()) {
        router.navigate('/login');
        return;
    }

    document.getElementById('app').innerHTML = `
        <div class="main-content">
            <div class="header">
                <h1>Companies</h1>
                <button class="btn btn-primary" onclick="showModal('company-modal')">Add Company</button>
            </div>

            <div class="breadcrumb">
                <a href="#/dashboard">Home</a> / Companies
            </div>

            <div class="card">
                <div class="card-body">
                    <table class="table" id="companies-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>GSTIN</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Companies will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Company Modal -->
        <div id="company-modal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Add Company</h2>
                    <span class="close" onclick="hideModal('company-modal')">&times;</span>
                </div>
                <form id="company-form">
                    <div class="form-group">
                        <label for="company-name">Name</label>
                        <input type="text" id="company-name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="company-gstin">GSTIN</label>
                        <input type="text" id="company-gstin" name="gstin">
                    </div>
                    <div class="form-group">
                        <label for="company-pan">PAN</label>
                        <input type="text" id="company-pan" name="pan">
                    </div>
                    <div class="form-group">
                        <label for="company-address">Address</label>
                        <textarea id="company-address" name="address"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="company-city">City</label>
                        <input type="text" id="company-city" name="city">
                    </div>
                    <div class="form-group">
                        <label for="company-state">State</label>
                        <select id="company-state" name="state">
                            <option value="">Select State</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Rajasthan">Rajasthan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="company-pincode">Pincode</label>
                        <input type="text" id="company-pincode" name="pincode">
                    </div>
                    <div class="form-group">
                        <label for="company-phone">Phone</label>
                        <input type="text" id="company-phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="company-email">Email</label>
                        <input type="email" id="company-email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="company-owner">Owner Name</label>
                        <input type="text" id="company-owner" name="owner_name">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Company</button>
                    <button type="button" class="btn btn-secondary" onclick="hideModal('company-modal')">Cancel</button>
                </form>
            </div>
        </div>
    `;

    await loadCompanies();
}

// Other page renderers would follow similar patterns...

// Data loading functions
async function loadDashboardData() {
    try {
        const [customers, suppliers, products, invoices] = await Promise.all([
            state.fetchCustomers(),
            state.fetchSuppliers(),
            state.fetchProducts(),
            state.fetchInvoices()
        ]);

        document.getElementById('total-customers').textContent = customers.length;
        document.getElementById('total-suppliers').textContent = suppliers.length;
        document.getElementById('total-products').textContent = products.length;
        document.getElementById('total-invoices').textContent = invoices.length;

        // Load recent invoices
        const recentInvoicesTable = document.getElementById('recent-invoices').getElementsByTagName('tbody')[0];
        recentInvoicesTable.innerHTML = invoices.slice(0, 5).map(invoice => `
            <tr>
                <td>${invoice.invoice_number}</td>
                <td>${formatDate(invoice.invoice_date)}</td>
                <td>${invoice.customer ? invoice.customer.name : 'N/A'}</td>
                <td>${formatCurrency(invoice.total_amount)}</td>
                <td><span class="badge">${invoice.status}</span></td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showAlert('error', 'Failed to load dashboard data');
    }
}

async function loadCompanies() {
    try {
        const companies = await api.get('/companies');
        const companiesTable = document.getElementById('companies-table').getElementsByTagName('tbody')[0];
        companiesTable.innerHTML = companies.map(company => `
            <tr>
                <td>${company.name}</td>
                <td>${company.gstin || 'N/A'}</td>
                <td>${company.address || 'N/A'}</td>
                <td>${company.phone || 'N/A'}</td>
                <td>
                    <button class="btn btn-secondary btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading companies:', error);
        showAlert('error', 'Failed to load companies');
    }
}
